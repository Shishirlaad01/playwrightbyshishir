class Loginpage {
    constructor(page) 
    {
        this.page=page
        this.username= page.getByRole('textbox', { name: 'Enter Email' });
        this.password= page.getByPlaceholder('Enter Password');  
        this.loginbutton= page.getByRole('button', { name: /Sign in/i })
    }

    async logintoapp(){
        await this.username.fill("admin@email.com")
        await this.password.fill("Admin@213")
        await this.loginbutton.click()
    }

}
module.exports=Loginpage;