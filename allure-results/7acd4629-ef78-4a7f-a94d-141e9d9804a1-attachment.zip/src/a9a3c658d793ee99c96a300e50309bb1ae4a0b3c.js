const { test, expect } = require('@playwright/test')
const Loginpage = require('../pages/loginpage')
const logout = require('../pages/logout');

test('POM', async ({ page }) => {
    await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
    //const login = new Loginpage(page);
    //const logout = new logout(page);
    await Loginpage.logintoapp();
    await logout.logoutaction();

})