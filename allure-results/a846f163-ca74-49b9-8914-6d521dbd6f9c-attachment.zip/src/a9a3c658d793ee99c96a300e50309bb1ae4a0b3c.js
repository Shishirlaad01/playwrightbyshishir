const { test, expect } = require('@playwright/test')
const pom = require("../pages/loginpage")
const Loginpage = require('../pages/loginpage')
test('POM', async ({ page }) => {
    await page.goto('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')
    const login = new Loginpage(page)
    await login.logintoapp()
})